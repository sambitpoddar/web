---
name: Question
about: Ask a (simple) question about Whoogle
title: "[QUESTION] <question here>"
labels: question
assignees: ''

---

Type out your question here. Please make sure that this is a topic that isn't already covered in the README.
